<!-- src/views/QueueView.vue -->
<script setup>
import { ref, onMounted, watch } from 'vue'

const issues = ref([]) 
const loading = ref(true)

// Filter State
const searchQuery = ref('')
const priorityFilter = ref('all')
let debounceTimeout = null

// The dynamic fetch function
const fetchAllIssues = async () => {
  loading.value = true
  try {
	// Build the URL with our state variables
	const params = new URLSearchParams()
	if (searchQuery.value) params.append('search', searchQuery.value)
	if (priorityFilter.value && priorityFilter.value !== 'all') {
	params.append('priority', priorityFilter.value)
	}

	const token = localStorage.getItem('bunny_token')
	const response = await fetch(`http://localhost:8080/issues?${params.toString()}`, {
  headers: {
    'Authorization': `Bearer ${token}` // 👈 Attach it to the request!
  }
})
    issues.value = await response.json()
  } catch (error) {
    console.error("Failed to fetch queue:", error)
  } finally {
    loading.value = false
  }
}

// Load everything on startup
onMounted(fetchAllIssues)

// WATCHER 1: When priority changes, fetch immediately
watch(priorityFilter, () => {
  fetchAllIssues()
})

// WATCHER 2: When search changes, wait 300ms before fetching (Debouncing)
watch(searchQuery, () => {
  clearTimeout(debounceTimeout)
  debounceTimeout = setTimeout(() => {
    fetchAllIssues()
  }, 300)
})
</script>

<template>
  <main class="page-container">
    <div class="header">
      <h1>Issue Queue</h1>
      
      <!-- The activated filter bar! -->
      <div class="filter-bar">
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="🔍 Search titles & descriptions..." 
        />
        
        <select v-model="priorityFilter">
          <option value="all">All Priorities</option>
          <option value="critical">Critical</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>
    </div>

    <div v-if="loading" class="loading">Loading queue...</div>
    
    <!-- Empty State UI -->
    <div v-else-if="issues.length === 0" class="empty-state">
      No issues found matching your filters.
    </div>

    <div v-else class="queue-container">
      <!-- Clean Flexbox layout (replaces the old ul/li setup) -->
      <div class="issue-list">
        <div v-for="issue in issues" :key="issue.issue_key" class="issue-row">
          
          <span class="issue-key">{{ issue.issue_key }}</span>
          
          <router-link :to="`/issue/${issue.issue_key}`" class="issue-title">
            {{ issue.title }}
          </router-link>
          
          <span v-if="issue.attachment_count > 0" class="attachment-badge" title="Has Attachments">
            📎 {{ issue.attachment_count }}
          </span>
          
          <!-- This pushes the priority badge to the far right -->
          <div class="spacer"></div>
          
          <span :class="['badge', issue.custom_data?.priority || 'standard']">
            {{ (issue.custom_data?.priority || 'standard').toUpperCase() }}
          </span>
          
        </div>
      </div>
    </div>
  </main>
</template>

<style scoped>
/* Most styles remain the same, just updated the filter-bar */
.page-container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }

.filter-bar { display: flex; gap: 10px; }
.filter-bar input { padding: 10px 15px; border: 1px solid #ddd; border-radius: 6px; width: 300px; font-size: 0.95em; }
.filter-bar select { padding: 10px 15px; border: 1px solid #ddd; border-radius: 6px; background: white; font-size: 0.95em; cursor: pointer; }

.queue-container { background: white; border: 1px solid #e4e4e7; border-radius: 8px; overflow: hidden; }
.issue-list { list-style: none; padding: 0; margin: 0; }
.list-row { display: flex; align-items: center; padding: 15px 20px; border-bottom: 1px solid #f4f4f5; text-decoration: none; color: #333; transition: background 0.1s; }
.list-row:hover { background: #fafafa; }
.list-row:last-child { border-bottom: none; }

.id-col { font-weight: bold; width: 100px; color: #646cff; }
.title-col { flex-grow: 1; font-weight: 500; }

.badge { font-size: 0.75em; padding: 4px 10px; border-radius: 12px; background: #eee; text-transform: uppercase; font-weight: bold; }
.badge.critical { background: #fee2e2; color: #991b1b; }
.badge.medium { background: #fef3c7; color: #92400e; }

.empty-state { text-align: center; padding: 40px; background: white; border: 1px dashed #ccc; border-radius: 8px; color: #666; }
.issue-list { 
  background: white; 
  border: 1px solid #e4e4e7; 
  border-radius: 8px; 
  overflow: hidden; 
  margin-top: 20px;
}

.issue-row { 
  display: flex; 
  align-items: center; 
  padding: 15px 20px; 
  border-bottom: 1px solid #e4e4e7; 
  gap: 15px; /* Perfect spacing between items */
}

.issue-row:last-child { border-bottom: none; }

.issue-key { font-weight: bold; color: #646cff; min-width: 90px; }

.issue-title { color: #18181b; text-decoration: none; font-weight: 500; font-size: 1.05em; }
.issue-title:hover { text-decoration: underline; color: #646cff; }

.attachment-badge { 
  font-size: 0.85em; 
  color: #52525b; 
  background: #f4f4f5; 
  padding: 3px 8px; 
  border-radius: 12px; 
  display: inline-flex; 
  align-items: center; 
  border: 1px solid #e4e4e7;
}

.spacer { flex: 1; } /* This pushes everything after it to the right */

.empty-state { padding: 30px; text-align: center; color: #a1a1aa; font-style: italic; }
</style>
