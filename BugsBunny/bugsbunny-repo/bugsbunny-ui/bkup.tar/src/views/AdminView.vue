<!-- src/views/AdminView.vue -->
<script setup>
import { ref, onMounted } from 'vue'

const projectForm = ref({ name: '', project_key: '', description: '' })
const userForm = ref({ email: '', password: '', role: 'developer' })
const message = ref('')

const users = ref([])
const projects = ref([])

const fetchUsers = async () => {
  const token = localStorage.getItem('bunny_token')
  const response = await fetch('http://localhost:8080/admin/users', {
    headers: { 'Authorization': `Bearer ${token}` }
  })
  if (response.ok) users.value = await response.json()
}

const fetchProjects = async () => {
  const token = localStorage.getItem('bunny_token')
  const response = await fetch('http://localhost:8080/admin/projects', {
    headers: { 'Authorization': `Bearer ${token}` }
  })
  if (response.ok) projects.value = await response.json()
}

// Load data when the page opens
onMounted(() => {
  fetchUsers()
  fetchProjects()
})

const toggleUserStatus = async (id) => {
  const token = localStorage.getItem('bunny_token')
  await fetch(`http://localhost:8080/admin/users/${id}/toggle`, {
    method: 'PUT',
    headers: { 'Authorization': `Bearer ${token}` }
  })
  fetchUsers()
}

const resetPassword = async (id) => {
  const newPassword = prompt("Enter new password for this user:")
  if (!newPassword) return

  const token = localStorage.getItem('bunny_token')
  await fetch(`http://localhost:8080/admin/users/${id}/password`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ password: newPassword })
  })
  alert("Password updated successfully!")
}

const archiveProject = async (id) => {
  if (!confirm("Are you sure you want to archive this project? It will no longer accept new bugs.")) return
  
  const token = localStorage.getItem('bunny_token')
  await fetch(`http://localhost:8080/admin/projects/${id}/archive`, {
    method: 'PUT',
    headers: { 'Authorization': `Bearer ${token}` }
  })
  fetchProjects()
}

const createProject = async () => {
  const token = localStorage.getItem('bunny_token')
  const res = await fetch('http://localhost:8080/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify(projectForm.value)
  })
  if (res.ok) {
    message.value = `Project ${projectForm.value.project_key} created successfully!`
    projectForm.value = { name: '', project_key: '', description: '' }
    await fetchProjects() 
    
    setTimeout(() => message.value = '', 3000)
  }
}

const createUser = async () => {
  const token = localStorage.getItem('bunny_token')
  const res = await fetch('http://localhost:8080/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify(userForm.value)
  })
  if (res.ok) {
    message.value = `User ${userForm.value.email} created successfully!`
    userForm.value = { email: '', password: '', role: 'developer' }
    await fetchUsers() 
    
    setTimeout(() => message.value = '', 3000)
  }
}
</script>

<template>
  <main class="admin-container">
    <h1>🛡️ Platform Administration</h1>
    <div v-if="message" class="success-msg">{{ message }}</div>

    <div class="admin-grid">
      <!-- Create Project Panel -->
      <div class="admin-panel">
        <h2>Create New Project</h2>
        <form @submit.prevent="createProject" class="admin-form">
          <label>Project Name</label>
          <input v-model="projectForm.name" placeholder="e.g. Mobile App" required />
          
          <label>Project Key (Prefix)</label>
          <input v-model="projectForm.project_key" placeholder="e.g. MOB" required maxlength="10" style="text-transform: uppercase;" />
          
          <label>Description</label>
          <textarea v-model="projectForm.description" rows="2"></textarea>
          
          <button type="submit">Create Project</button>
        </form>
      </div>

      <!-- Create User Panel -->
      <div class="admin-panel">
        <h2>Invite User</h2>
        <form @submit.prevent="createUser" class="admin-form">
          <label>Email Address</label>
          <input type="email" v-model="userForm.email" required />
          
          <label>Temporary Password</label>
          <input type="password" v-model="userForm.password" required />
          
          <label>Platform Role</label>
          <select v-model="userForm.role">
            <option value="developer">Developer</option>
            <option value="manager">Manager</option>
            <option value="admin">Administrator</option>
          </select>
          
          <button type="submit">Create User</button>
        </form>
      </div>

      <!-- NEW: Manage Projects Panel -->
      <div class="admin-panel">
        <h2>Manage Projects</h2>
        <ul class="admin-list">
          <li v-for="project in projects" :key="project.id" class="list-item">
            <span><strong>{{ project.project_key }}</strong>: {{ project.name }} {{ project.is_archived ? '(Archived)' : '' }}</span>
            <button v-if="!project.is_archived" @click="archiveProject(project.id)" class="btn-sm btn-danger">Archive</button>
          </li>
        </ul>
      </div>

      <!-- NEW: Manage Users Panel -->
      <div class="admin-panel">
        <h2>Manage Users</h2>
        <ul class="admin-list">
          <li v-for="user in users" :key="user.id" class="list-item">
            <div class="user-info">
              <span>{{ user.email }}</span>
              <span class="user-role badge">{{ user.role }}</span>
              <span v-if="user.is_active === false" class="deactivated-tag">Deactivated</span>
            </div>
            <div class="actions">
              <button @click="resetPassword(user.id)" class="btn-sm">🔑 Reset</button>
              <button @click="toggleUserStatus(user.id)" class="btn-sm" :class="{ 'btn-danger': user.is_active !== false }">
                {{ user.is_active !== false ? 'Deactivate' : 'Reactivate' }}
              </button>
            </div>
          </li>
        </ul>
      </div>
      
    </div>
  </main>
</template>

<style scoped>
.admin-container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
.success-msg { background: #dcfce7; color: #166534; padding: 12px; border-radius: 6px; margin-bottom: 20px; text-align: center; font-weight: bold; }
.admin-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
.admin-panel { background: white; padding: 25px; border-radius: 8px; border: 1px solid #e4e4e7; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
.admin-form { display: flex; flex-direction: column; gap: 10px; }
label { font-size: 0.9em; font-weight: bold; color: #3f3f46; margin-top: 10px; }
input, textarea, select { padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-family: inherit; }
button { margin-top: 15px; background: #18181b; color: white; border: none; padding: 12px; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; }
button:hover { background: #3f3f46; }
.admin-list { list-style: none; padding: 0; margin: 0; }
.list-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #e4e4e7; }
.list-item:last-child { border-bottom: none; }
.actions { display: flex; gap: 8px; }
.user-info { display: flex; flex-direction: column; gap: 4px; }
.user-role { font-size: 0.75em; align-self: flex-start; }
.deactivated-tag { font-size: 0.75em; color: #dc2626; font-weight: bold; }
.btn-sm { padding: 6px 10px; font-size: 0.85em; background: #e4e4e7; color: #18181b; border: none; border-radius: 4px; cursor: pointer; }
.btn-danger { background: #fee2e2; color: #dc2626; }
.btn-danger:hover { background: #fca5a5; }
</style>
