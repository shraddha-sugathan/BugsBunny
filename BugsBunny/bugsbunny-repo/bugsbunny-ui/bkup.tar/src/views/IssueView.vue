<!-- src/views/IssueView.vue -->
<script setup>
import { ref, onMounted, defineAsyncComponent, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const issue = ref(null)
const loading = ref(true)

// NEW: Edit Mode State
const isEditing = ref(false)
const editForm = ref({ title: '', body: '', priority: '' })
const isSaving = ref(false)

// Add these reactive variables near the top
const comments = ref([])
const newComment = ref('')
const isSubmittingComment = ref(false)

const attachments = ref([])
const isUploading = ref(false)

// New Multi-file Staging for Comments/Edits
const stagedFiles = ref([])

const handleFileSelect = (event) => {
  stagedFiles.value.push(...Array.from(event.target.files))
  event.target.value = ''
}
const removeFile = (index) => stagedFiles.value.splice(index, 1)

// Upgrade postComment to handle Two-Step Commit
const postComment = async () => {
  if (!newComment.value.trim() && stagedFiles.value.length === 0) return
  isSubmittingComment.value = true
  const token = localStorage.getItem('bunny_token')

  // 1. Post text comment (if any)
  if (newComment.value.trim()) {
    await fetch(`http://localhost:8080/issues/${route.params.id}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ body: newComment.value })
    })
  }

  // 2. Upload attached files
  if (stagedFiles.value.length > 0) {
    const uploadPromises = stagedFiles.value.map(file => {
      const formData = new FormData()
      formData.append('file', file)
      return fetch(`http://localhost:8080/issues/${route.params.id}/attachments`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      })
    })
    await Promise.all(uploadPromises)
  }
  
  newComment.value = ''
  stagedFiles.value = [] // Clear staging
  await fetchComments(route.params.id) 
  await fetchAttachments(route.params.id) // Refresh unified gallery
  isSubmittingComment.value = false
}

const fetchAttachments = async (id) => {
  const token = localStorage.getItem('bunny_token')
  const res = await fetch(`http://localhost:8080/issues/${id}/attachments`, {
    headers: { 'Authorization': `Bearer ${token}` }
  })
  if (res.ok) attachments.value = await res.json()
}

// Call fetchAttachments(id) inside your existing fetchIssue() function!
// Example: await fetchAttachments(id)

const handleFileUpload = async (event) => {
  const file = event.target.files[0]
  if (!file) return
  
  isUploading.value = true
  const formData = new FormData()
  formData.append('file', file)

  const token = localStorage.getItem('bunny_token')
  await fetch(`http://localhost:8080/issues/${route.params.id}/attachments`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` }, // NO Content-Type here!
    body: formData
  })

  await fetchAttachments(route.params.id) // Refresh list
  isUploading.value = false
}

// Create the fetch function
const fetchComments = async (id) => {
  const token = localStorage.getItem('bunny_token')
  const res = await fetch(`http://localhost:8080/issues/${id}/comments`, {
    headers: { 'Authorization': `Bearer ${token}` }
  })
  if (res.ok) comments.value = await res.json()
}

// Update your existing fetchIssue to also call fetchComments
const fetchIssue = async (id) => {
  loading.value = true
  try {
    const token = localStorage.getItem('bunny_token')
    const response = await fetch(`http://localhost:8080/issues/${id}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    issue.value = await response.json()
    
    // 👈 THIS IS THE CRITICAL MISSING LINE
    await fetchAttachments(id) 
    
  } catch (error) {
    console.error(error)
  } finally {
    loading.value = false
  }
}

const SlaPluginWidget = defineAsyncComponent(() => import('../ui-plugins/SlaWidget.vue'))



// NEW: Populate the form and enter Edit Mode
const startEditing = () => {
  editForm.value = {
    title: issue.value.title,
    body: issue.value.body,
    status: issue.value.status || 'open',
    priority: issue.value.custom_data.priority || 'low',
    component: issue.value.custom_data.component || '',
    module: issue.value.custom_data.module || '',
    release: issue.value.custom_data.release || ''
  }
  isEditing.value = true
}

// NEW: Send the PUT request to Go
const saveEdit = async () => {
  isSaving.value = true
  try {
    const token = localStorage.getItem('bunny_token')
    const response = await fetch(`http://localhost:8080/issues/${route.params.id}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(editForm.value)
    })

    // --- NEW: Handle Backend Errors & WASM Rejections ---
    if (!response.ok) {
      const errorText = await response.text()
      
      if (response.status === 403) {
        alert(`🛑 Transition Rejected:\n${errorText}`)
        isEditing.value = false           // Kick them out of edit mode
        await fetchIssue(route.params.id) // Snap the UI back to reality
        return
      }
      
      throw new Error(errorText || 'Failed to update issue')
    }
    // ----------------------------------------------------

    if (response.ok) {
      isEditing.value = false
      await fetchIssue(route.params.id) // Re-fetch to update the view
    }
  } catch (error) {
    console.error("Failed to update issue:", error)
    alert("An error occurred while saving. Please try again.")
  } finally {
    isSaving.value = false
  }
}

// Add this anywhere inside your <script setup> block

const deleteIssue = async () => {
  // Safety check!
  if (!window.confirm(`Are you sure you want to delete ${issue.value.issue_key}? This cannot be undone.`)) {
    return
  }
  
  try {
    const token = localStorage.getItem('bunny_token')
const response = await fetch(`http://localhost:8080/issues/${route.params.id}`, {
  method: 'DELETE',
  headers: { 'Authorization': `Bearer ${token}` }
})

    if (response.ok) {
      // Send the user back to the queue page automatically
      router.push('/queue')
    }
  } catch (error) {
    console.error("Failed to delete issue:", error)
  }
}

onMounted(() => fetchIssue(route.params.id))
watch(() => route.params.id, (newId) => { if (newId) fetchIssue(newId) })
</script>
<template>
  <main class="page-container">
    <router-link to="/queue" class="back-link">← Back to Queue</router-link>
    
    <div v-if="loading" class="loading">Loading issue...</div>
    
    <div v-else-if="issue" class="issue-card">
      
      <!-- VIEW MODE -->
      <div v-if="!isEditing">
        
        <!-- THE SINGLE, CORRECT HEADER -->
        <div class="card-header">
          <span class="badge">{{ issue.issue_key }}</span>
          <div class="header-actions">
            <button @click="startEditing" class="edit-btn">✏️ Edit</button>
            <button @click="deleteIssue" class="delete-btn">🗑️ Delete</button>
          </div>
        </div>
        
        <h2>{{ issue.title }}</h2>
	<div class="issue-meta">
	  <span class="meta-tag"><strong>Status:</strong> {{ issue.status }}</span>
	  <span class="meta-tag"><strong>Release:</strong> {{ issue.custom_data.release || 'Unscheduled' }}</span>
	  <span class="meta-tag"><strong>Component:</strong> {{ issue.custom_data.component || 'N/A' }}</span>
	  <span class="meta-tag"><strong>Module:</strong> {{ issue.custom_data.module || 'N/A' }}</span>
	  <span :class="['badge', issue.custom_data.priority]">{{ issue.custom_data.priority }}</span>
	</div>
        <p class="body-text">{{ issue.body }}</p>
        
        <div class="plugin-slot">
          <p class="slot-label">-- Plugin Slot: Issue Bottom --</p>
          <component :is="SlaPluginWidget" :issueData="issue" />
        </div>
<!-- UNIFIED ATTACHMENTS GALLERY -->
<div v-if="attachments && attachments.length > 0" class="unified-gallery">
  <div v-for="att in attachments" :key="att.id" class="attachment-card-wrapper">
    <!-- The download attribute forces a file save instead of a new tab -->
    <a :href="att.file_url" target="_blank" download class="attachment-card">
      📎 {{ att.filename }} (Download)
    </a>
    <span class="attachment-meta">Uploaded by: {{ att.user_email?.split('@')[0] || 'System' }}</span>
  </div>
</div>
        <!-- COMMENTS SECTION -->
<div class="comments-section">
  <h3>Discussion</h3>
  
  <div v-if="comments.length === 0" class="no-comments">
    No comments yet. Start the conversation!
  </div>
  
  <div class="comment-list">
    <div v-for="c in comments" :key="c.id" class="comment-bubble">
      <div class="comment-header">
        <strong>👤 {{ c.user_email }}</strong>
        <span class="comment-date">{{ new Date(c.created_at).toLocaleString() }}</span>
      </div>
      <div class="comment-body">{{ c.body }}</div>
    </div>
  </div>

<form @submit.prevent="postComment" class="comment-form">
  <textarea v-model="newComment" rows="3" placeholder="Add a comment or attach files..."></textarea>
  
  <!-- Staged Files List -->
  <div v-if="stagedFiles.length > 0" class="staged-list">
    <div v-for="(file, index) in stagedFiles" :key="index" class="staged-item">
      📎 {{ file.name }}
      <button type="button" @click="removeFile(index)" class="btn-remove">❌</button>
    </div>
  </div>

  <div class="comment-actions">
    <input type="file" @change="handleFileSelect" multiple class="file-input-sm" id="commentFile" />
    <label for="commentFile" class="btn-attach">📎 Attach</label>
    
    <button type="submit" :disabled="isSubmittingComment">
      {{ isSubmittingComment ? 'Posting...' : 'Post' }}
    </button>
  </div>
</form>
</div>
      </div>

      <!-- EDIT MODE -->
      <form v-else @submit.prevent="saveEdit" class="edit-form">
        <div class="card-header">
          <span class="badge">{{ issue.issue_key }} (Editing)</span>
        </div>
        
        <div class="form-group">
          <label>Title:</label>
          <input v-model="editForm.title" required />
        </div>
        
        <div class="form-group">
          <label>Description:</label>
          <!-- Note: I kept this editable for now, but per our previous chat, 
               you can easily add 'disabled' here later if you want to lock it! -->
          <textarea v-model="editForm.body" rows="4" required></textarea>
        </div>
        
        <div class="form-group">
          <label>Priority:</label>
          <select v-model="editForm.priority">
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="critical">Critical</option>
          </select>
        </div>
        
        <div class="form-group">
	  <label>Status:</label>
	  <select v-model="editForm.status">
	    <option value="open">Open</option>
	    <option value="accepted">Accepted</option>
	    <option value="in_progress">In Progress</option>
	    <option value="on_hold">On Hold</option>
	    <option value="deferred">Deferred</option>
	    <option value="resolved">Resolved</option>
	    <option value="rejected">Rejected</option>
	    <option value="closed">Closed</option>
	  </select>
	</div>

	<!-- Grouping these makes the UI cleaner -->
	<div style="display: flex; gap: 10px;">
	  <div class="form-group" style="flex: 1;">
	    <label>Component:</label>
	    <input v-model="editForm.component" />
	  </div>
	  <div class="form-group" style="flex: 1;">
	    <label>Module:</label>
	    <input v-model="editForm.module" />
	  </div>
	  <div class="form-group" style="flex: 1;">
	    <label>Release:</label>
	    <input v-model="editForm.release" />
	  </div>
	</div>

        <div class="action-buttons">
          <button type="button" @click="isEditing = false" class="cancel-btn">Cancel</button>
          <button type="submit" :disabled="isSaving" class="save-btn">
            {{ isSaving ? 'Saving...' : 'Save Changes' }}
          </button>
        </div>
      </form>
      
    </div>
  </main>
</template>
<style scoped>
.page-container { max-width: 800px; margin: 40px auto; padding: 0 20px; }
.back-link { text-decoration: none; color: #a1a1aa; font-weight: 600; display: inline-block; margin-bottom: 20px;}
.back-link:hover { color: #18181b; }
.issue-meta { display: flex; gap: 15px; background: #f4f4f5; padding: 10px 15px; border-radius: 6px; margin-bottom: 20px; align-items: center; flex-wrap: wrap;}
.meta-tag { font-size: 0.85em; color: #3f3f46; }
.issue-card { background: white; border: 1px solid #e4e4e7; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
.card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
.badge { background: #18181b; color: white; padding: 4px 10px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }
.body-text { white-space: pre-wrap; color: #3f3f46; line-height: 1.5; }

.edit-btn { background: none; border: 1px solid #e4e4e7; padding: 6px 12px; border-radius: 4px; cursor: pointer; transition: background 0.2s; }
.edit-btn:hover { background: #f4f4f5; }

.plugin-slot { margin-top: 40px; padding: 20px; border: 2px dashed #e4e4e7; border-radius: 8px; background: #fafafa;}
.slot-label { font-size: 0.75em; color: #a1a1aa; text-transform: uppercase; margin-top: 0; font-weight: bold; }

/* Edit Form Styles */
.edit-form { display: flex; flex-direction: column; gap: 15px; }
.form-group { display: flex; flex-direction: column; gap: 5px; }
.form-group label { font-size: 0.9em; font-weight: bold; color: #3f3f46; }
input, textarea, select { padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: inherit; }
.action-buttons { display: flex; gap: 10px; justify-content: flex-end; margin-top: 10px; }
.save-btn { background: #18181b; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; }
.cancel-btn { background: white; color: #3f3f46; border: 1px solid #ccc; padding: 10px 20px; border-radius: 4px; cursor: pointer; }
.header-actions { display: flex; gap: 10px; }
.delete-btn { background: none; border: 1px solid #fee2e2; color: #991b1b; padding: 6px 12px; border-radius: 4px; cursor: pointer; transition: background 0.2s; }
.delete-btn:hover { background: #fee2e2; }
.comments-section { margin-top: 40px; border-top: 1px solid #e4e4e7; padding-top: 20px; }
.no-comments { color: #a1a1aa; font-style: italic; margin-bottom: 20px; }
.comment-list { display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px; }
.comment-bubble { background: #fafafa; border: 1px solid #e4e4e7; padding: 15px; border-radius: 8px; }
.comment-header { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.9em; }
.comment-date { color: #a1a1aa; }
.comment-body { white-space: pre-wrap; color: #3f3f46; line-height: 1.4; }
.comment-form { display: flex; flex-direction: column; gap: 10px; align-items: flex-end; }
.comment-form textarea { width: 100%; box-sizing: border-box; }
.comment-form button { background: #646cff; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer; }
.attachments-section { margin-top: 30px; border-top: 1px solid #e4e4e7; padding-top: 20px; }
.upload-controls { margin-bottom: 15px; }
.attachment-gallery { display: flex; gap: 10px; flex-wrap: wrap; }
.attachment-card { background: #e0e7ff; color: #4338ca; padding: 10px 15px; border-radius: 6px; text-decoration: none; font-weight: 500; font-size: 0.9em; transition: 0.2s; }
.attachment-card:hover { background: #c7d2fe; }
.staged-list { margin: 10px 0; display: flex; flex-direction: column; gap: 5px; }
.staged-item { 
  display: flex; 
  justify-content: space-between; 
  align-items: center; /* Centers the X vertically with the text */
  background: #fffbeb; 
  border: 1px solid #fcd34d; 
  padding: 8px 12px; 
  border-radius: 4px; 
  font-size: 0.85em; 
  gap: 15px; /* Adds breathing room between the filename and the button */
}

.btn-remove { 
  background: transparent !important; /* Strips the purple */
  padding: 0 !important; /* Strips the bulky padding */
  border: none; 
  cursor: pointer; 
  color: #dc2626; 
  font-size: 1.1em;
  line-height: 1;
  min-width: auto;
}

.btn-remove:hover {
  transform: scale(1.1); /* Smooth hover pop instead of a color change */
}

.unified-gallery { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px; background: #fafafa; padding: 15px; border-radius: 6px; border: 1px dashed #d4d4d8; }
.attachment-card-wrapper { display: flex; flex-direction: column; gap: 4px; }
.attachment-card { background: #e0e7ff; color: #4338ca; padding: 8px 12px; border-radius: 4px; text-decoration: none; font-size: 0.85em; font-weight: bold; }
.attachment-card:hover { background: #c7d2fe; }
.attachment-meta { font-size: 0.7em; color: #a1a1aa; padding-left: 2px; }

.comment-actions { display: flex; justify-content: space-between; width: 100%; align-items: center; margin-top: 10px; }
.file-input-sm { display: none; /* Hide default input */ }
.btn-attach { cursor: pointer; background: #e4e4e7; padding: 8px 12px; border-radius: 4px; font-size: 0.85em; font-weight: bold; color: #3f3f46; }
.btn-attach:hover { background: #d4d4d8; }
</style>

