package main

import (
	"context"	
    	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"io"
	"time"
	"strings"
	"path/filepath"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// Global database pool
var dbpool *pgxpool.Pool
var pluginManager *PluginManager

// --- V2 DATA MODELS ---

// Secret key for signing tokens (In production, load this from .env!)
var jwtSecret = []byte("super_secret_bunny_key")

type LoginRequest struct {
    Email    string `json:"email"`
    Password string `json:"password"`
}

// The data we pack inside the JWT token
type Claims struct {
    UserID int    `json:"user_id"`
    Role   string `json:"role"`
    jwt.RegisteredClaims
}

type User struct {
    ID           int    `json:"id"`
    Email        string `json:"email"`
    PasswordHash string `json:"-"` // The hyphen ensures passwords NEVER leak to the Vue frontend!
    Role         string `json:"role"`
    IsActive     bool   `json:"is_active"`
}

type Project struct {
    ID          int    `json:"id"`
    ProjectKey  string `json:"project_key"`
    Name        string `json:"name"`
    Description string `json:"description"`
    IsArchived  bool   `json:"is_archived"`
}

type Comment struct {
    ID        int       `json:"id"`
    IssueKey  string    `json:"issue_key"`
    UserID    int       `json:"user_id"`
    UserEmail string    `json:"user_email"` 
    Body      string    `json:"body"`
    CreatedAt time.Time `json:"created_at"`
}

type Attachment struct {
    ID        int       `json:"id"`
    IssueKey  string    `json:"issue_key"`
    Filename  string    `json:"filename"`
    FileURL   string    `json:"file_url"`
    CreatedAt time.Time `json:"created_at"`
}

// This handles both reading from the DB and receiving from Vue
type Issue struct {
    IssueKey   string          `json:"issue_key"`
    ProjectID  int             `json:"project_id"`
    Title      string          `json:"title"`
    Body       string          `json:"body"`
    Status     string          `json:"status"`
    Resolution *string         `json:"resolution"`  // Pointer because it can be NULL
    ReporterID int             `json:"reporter_id"`
    AssigneeID *int            `json:"assignee_id"` // Pointer because it can be unassigned (NULL)
    CustomData json.RawMessage `json:"custom_data"` // JSONB payload
    
    // --- Virtual Field (Catches the form data from Vue) ---
    Priority   	string          `json:"priority,omitempty"`
    Component 	string 		`json:"component,omitempty"`
    Module    	string 		`json:"module,omitempty"`
    Release   	string 		`json:"release,omitempty"`
    AttachmentCount int 	`json:"attachment_count"`
}

type UserProfile struct {
    Email         string      `json:"email"`
    TotalIssues   int         `json:"total_issues"`
    ResolvedCount int         `json:"resolved_count"`
    Issues        []IssueStub `json:"issues"`
}

type IssueStub struct {
    IssueKey string `json:"issue_key"`
    Title    string `json:"title"`
    Status   string `json:"status"`
}

func userProfileHandler(w http.ResponseWriter, r *http.Request) {
    userID := r.Context().Value("userID").(int)
    var profile UserProfile

    // 1. Get user email
    dbpool.QueryRow(context.Background(), "SELECT email FROM users WHERE id = $1", userID).Scan(&profile.Email)

    // 2. Calculate Metrics
    dbpool.QueryRow(context.Background(), "SELECT COUNT(*) FROM issues WHERE reporter_id = $1", userID).Scan(&profile.TotalIssues)
    dbpool.QueryRow(context.Background(), "SELECT COUNT(*) FROM issues WHERE reporter_id = $1 AND status = 'resolved'", userID).Scan(&profile.ResolvedCount)

    // 3. Fetch the user's issues
    rows, _ := dbpool.Query(context.Background(), "SELECT issue_key, title, status FROM issues WHERE reporter_id = $1 ORDER BY issue_key DESC", userID)
    defer rows.Close()
    
    for rows.Next() {
        var i IssueStub
        rows.Scan(&i.IssueKey, &i.Title, &i.Status)
        profile.Issues = append(profile.Issues, i)
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(profile)
}

func getCommentsHandler(w http.ResponseWriter, r *http.Request) {
    issueKey := r.PathValue("id")
    
    // We JOIN with the users table to get the email address of the commenter
    query := `
        SELECT c.id, c.issue_key, c.user_id, u.email, c.body, c.created_at 
        FROM issue_comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.issue_key = $1
        ORDER BY c.created_at ASC
    `
    
    rows, err := dbpool.Query(context.Background(), query, issueKey)
    if err != nil {
        http.Error(w, "Failed to fetch comments", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var comments []Comment
    for rows.Next() {
        var c Comment
        if err := rows.Scan(&c.ID, &c.IssueKey, &c.UserID, &c.UserEmail, &c.Body, &c.CreatedAt); err != nil {
            continue
        }
        comments = append(comments, c)
    }
    
    if comments == nil { comments = []Comment{} }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(comments)
}

func addCommentHandler(w http.ResponseWriter, r *http.Request) {
    issueKey := r.PathValue("id")
    userID := r.Context().Value("userID").(int) // Extracted from JWT!

    var c Comment
    if err := json.NewDecoder(r.Body).Decode(&c); err != nil {
        http.Error(w, "Invalid data", http.StatusBadRequest)
        return
    }

    err := dbpool.QueryRow(context.Background(),
        "INSERT INTO issue_comments (issue_key, user_id, body) VALUES ($1, $2, $3) RETURNING id, created_at",
        issueKey, userID, c.Body).Scan(&c.ID, &c.CreatedAt)
        
    if err != nil {
        http.Error(w, "Failed to add comment", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusCreated)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
    var req LoginRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    var user User
	// Fetch the user from the database
	    err := dbpool.QueryRow(context.Background(), 
	    "SELECT id, password_hash, role, is_active FROM users WHERE email = $1", req.Email).
	    Scan(&user.ID, &user.PasswordHash, &user.Role, &user.IsActive)

	if err == nil && !user.IsActive {
	    http.Error(w, "Account deactivated", http.StatusForbidden)
	    return
	}

    // Compare the submitted password with the database hash
    if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
        http.Error(w, "Invalid credentials", http.StatusUnauthorized)
        return
    }

    // Create the JWT Token valid for 24 hours
    expirationTime := time.Now().Add(24 * time.Hour)
    claims := &Claims{
        UserID: user.ID,
        Role:   user.Role,
        RegisteredClaims: jwt.RegisteredClaims{
            ExpiresAt: jwt.NewNumericDate(expirationTime),
        },
    }

    token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
    tokenString, err := token.SignedString(jwtSecret)
    if err != nil {
        http.Error(w, "Error generating token", http.StatusInternalServerError)
        return
    }

    // Send the token back to Vue!
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]string{
        "token": tokenString,
        "role":  user.Role,
        "email": req.Email,
    })
}
func adminMiddleware(next http.HandlerFunc) http.HandlerFunc {
    // 1. First, pass the request through the standard authMiddleware to verify the JWT
    return authMiddleware(func(w http.ResponseWriter, r *http.Request) {
        
        // 2. Extract the authenticated user's ID from the context (set by authMiddleware)
        userID := r.Context().Value("userID").(int)

        // 3. Query the database to check their role in real-time
        var role string
        err := dbpool.QueryRow(context.Background(), "SELECT role FROM users WHERE id = $1", userID).Scan(&role)
        
        // 4. Block the request if they aren't an admin
        if err != nil || role != "admin" {
            http.Error(w, "Forbidden: Admin access required", http.StatusForbidden)
            return
        }

        // 5. If they are an admin, allow the request to proceed!
        next.ServeHTTP(w, r)
    })
}

// The Bouncer: Protects our API routes
func authMiddleware(next http.HandlerFunc) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        authHeader := r.Header.Get("Authorization")
        
        if authHeader == "" {
            http.Error(w, "Forbidden: No token provided", http.StatusUnauthorized)
            return
        }

        // Strip the "Bearer " prefix from the header
        tokenString := strings.TrimPrefix(authHeader, "Bearer ")

        // Parse and validate the JWT signature
        claims := &Claims{}
        token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
            return jwtSecret, nil // Use our global secret key
        })

        if err != nil || !token.Valid {
            http.Error(w, "Forbidden: Invalid or expired token", http.StatusUnauthorized)
            return
        }

       	// Attach the userID from the token directly into the HTTP Request context
	// (You will need to create a custom type for context keys in production, but a string is fine for now)
	ctx := context.WithValue(r.Context(), "userID", claims.UserID)

	// Pass the upgraded request to the handler
	next.ServeHTTP(w, r.WithContext(ctx))
    }
}


// 2. Add the Create Handler
func createIssueHandler(w http.ResponseWriter, r *http.Request) {
	var issue Issue
	if err := json.NewDecoder(r.Body).Decode(&issue); err != nil {
	http.Error(w, err.Error(), http.StatusBadRequest)
	return
	}

	// Inside createIssueHandler...

	// Extract the dynamic User ID from the context injected by the middleware
	userID := r.Context().Value("userID").(int)

	// Create the custom data (Priority)
	customData := fmt.Sprintf(`{"priority": "%s", "component": "%s", "module": "%s", "release": "%s"}`, 
    issue.Priority, issue.Component, issue.Module, issue.Release)

	// Run the INSERT using the dynamic Project ID and Reporter (User) ID!
	_, err := dbpool.Exec(context.Background(), 
	    "INSERT INTO issues (project_id, reporter_id, status, issue_key, title, body, custom_data) VALUES ($1, $2, 'open', $3, $4, $5, $6)",
	    issue.ProjectID, userID, issue.IssueKey, issue.Title, issue.Body, customData)

	if err != nil {
	    fmt.Println("❌ DATABASE INSERT ERROR:", err) 
	    http.Error(w, err.Error(), http.StatusInternalServerError)
	    return
	}

	fmt.Println("✅ Successfully saved to DB:", issue.IssueKey)
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(map[string]string{"status": "success", "issue_key": issue.IssueKey})
}



// The new handler to fetch all issues
func getAllIssuesHandler(w http.ResponseWriter, r *http.Request) {
    search := r.URL.Query().Get("search")
    priority := r.URL.Query().Get("priority")

    // 1. Base Query with all the new V2 columns
    query := `
    SELECT issue_key, project_id, title, body, status, reporter_id, custom_data,
    (SELECT COUNT(*) FROM issue_attachments WHERE issue_key = issues.issue_key) AS attachment_count
    FROM issues WHERE 1=1
`
    var args []interface{}
    var argIndex = 1

    // 2. Search filter
    if search != "" {
        query += fmt.Sprintf(" AND (title ILIKE $%d OR body ILIKE $%d)", argIndex, argIndex)
        args = append(args, "%"+search+"%")
        argIndex++
    }

    // 3. Priority filter (JSONB)
    if priority != "" && priority != "all" {
        query += fmt.Sprintf(" AND custom_data->>'priority' = $%d", argIndex)
        args = append(args, priority)
        argIndex++
    }

    query += " ORDER BY issue_key DESC"

    // 4. Execute the query
    rows, err := dbpool.Query(context.Background(), query, args...)
    if err != nil {
        fmt.Println("❌ DATABASE QUERY ERROR:", err)
        http.Error(w, "Failed to fetch issues", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var issues []Issue
    for rows.Next() {
        var issue Issue
        if err := rows.Scan(&issue.IssueKey, &issue.ProjectID, &issue.Title, &issue.Body, &issue.Status, &issue.ReporterID, &issue.CustomData, &issue.AttachmentCount); err != nil {
    continue
}
        issues = append(issues, issue)
    }

    if issues == nil {
        issues = []Issue{}
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(issues)
}

// The new handler to update an existing issue
func updateIssueHandler(w http.ResponseWriter, r *http.Request) {
    // Go 1.22 makes getting the URL parameter this easy:
    id := r.PathValue("id") 

    var issue Issue
    if err := json.NewDecoder(r.Body).Decode(&issue); err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    // --- NEW: THE WASM CHECKPOINT ---
    var currentStatus, projectKey string
    
    // 1. Fetch the issue's current status and its project_key (e.g., "BUNNY")
    err := dbpool.QueryRow(context.Background(), 
        "SELECT i.status, p.project_key FROM issues i JOIN projects p ON i.project_id = p.id WHERE i.issue_key = $1", 
        id).Scan(&currentStatus, &projectKey)
    
    if err != nil {
        http.Error(w, "Issue not found", http.StatusNotFound)
        return
    }

    // 2. If the user is changing the status, consult the WASM engine!
    if issue.Status != "" && issue.Status != currentStatus {
        approved, err := ValidateTransition(projectKey, currentStatus, issue.Status)
        if err != nil {
            fmt.Printf("WASM Engine Error: %v\n", err) 
        }
        
        if !approved {
            // WASM REJECTED THE TRANSITION! Block the update.
            http.Error(w, "Workflow Rule Violation: Invalid status transition.", http.StatusForbidden)
            return
        }
    }
    // --- END WASM CHECKPOINT ---

    // Reconstruct the custom_data block with the new priority (Your exact code)
    customData := fmt.Sprintf(`{"priority": "%s", "component": "%s", "module": "%s", "release": "%s"}`, 
    issue.Priority, issue.Component, issue.Module, issue.Release)

    // The Exec query remains exactly the same! (Note we use '=' instead of ':=' for err here)
    _, err = dbpool.Exec(context.Background(), 
        "UPDATE issues SET title = $1, body = $2, status = $3, custom_data = $4 WHERE issue_key = $5",
        issue.Title, issue.Body, issue.Status, customData, id)
    
    if err != nil {
        fmt.Println("❌ DATABASE UPDATE ERROR:", err) 
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    fmt.Println("✅ Successfully updated DB:", id)
    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(map[string]string{"status": "success", "issue_key": id})
}

func deleteIssueHandler(w http.ResponseWriter, r *http.Request) {
    id := r.PathValue("id")
    
    // 1. Fetch attachments to clean up the physical hard drive
    rows, _ := dbpool.Query(context.Background(), "SELECT file_url FROM issue_attachments WHERE issue_key = $1", id)
    for rows.Next() {
        var fileURL string
        if rows.Scan(&fileURL) == nil {
            // Extract "123_image.png" from "http://localhost:8080/uploads/123_image.png"
            parts := strings.Split(fileURL, "/")
            diskFilename := parts[len(parts)-1]
            
            // Delete the physical file from the OS!
            os.Remove(filepath.Join("uploads", diskFilename)) 
        }
    }
    rows.Close() // Close the rows before executing the next query

    // 2. Delete the issue (PostgreSQL ON DELETE CASCADE will handle the DB rows)
    _, err := dbpool.Exec(context.Background(), "DELETE FROM issues WHERE issue_key = $1", id)
    if err != nil {
        http.Error(w, "Failed to delete issue", http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusNoContent)
}

func getProjectsHandler(w http.ResponseWriter, r *http.Request) {
    // We use COALESCE and check for NULL so older projects don't disappear
    query := `SELECT id, name, project_key, description, COALESCE(is_archived, false) 
              FROM projects 
              WHERE is_archived IS NULL OR is_archived = FALSE 
              ORDER BY id ASC`
              
    rows, err := dbpool.Query(context.Background(), query)
    if err != nil {
        http.Error(w, "Failed to fetch projects", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var projects []Project
    for rows.Next() {
        var p Project
        // We must scan exactly 5 fields to match the SQL query and the Project struct
        if err := rows.Scan(&p.ID, &p.Name, &p.ProjectKey, &p.Description, &p.IsArchived); err != nil {
            fmt.Println("Project scan error:", err)
            continue
        }
        projects = append(projects, p)
    }
    
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(projects)
}

func createProjectHandler(w http.ResponseWriter, r *http.Request) {
    var p Project
    if err := json.NewDecoder(r.Body).Decode(&p); err != nil {
        http.Error(w, "Invalid data", http.StatusBadRequest)
        return
    }

    err := dbpool.QueryRow(context.Background(),
        "INSERT INTO projects (project_key, name, description) VALUES ($1, $2, $3) RETURNING id",
        p.ProjectKey, p.Name, p.Description).Scan(&p.ID)
        
    if err != nil {
        http.Error(w, "Failed to create project", http.StatusInternalServerError)
        return
    }
    json.NewEncoder(w).Encode(p)
}

func createUserHandler(w http.ResponseWriter, r *http.Request) {
    // 1. Create a temporary struct to catch the exact JSON sent from Vue
    var req struct {
        Email    string `json:"email"`
        Password string `json:"password"`
        Role     string `json:"role"`
    }

    // 2. Decode the stream exactly once
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid data", http.StatusBadRequest)
        return
    }

    // 3. Hash the raw password
    hash, _ := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)

    // 4. Insert into the database
    var newUserID int
    err := dbpool.QueryRow(context.Background(),
        "INSERT INTO users (email, password_hash, role) VALUES ($1, $2, $3) RETURNING id",
        req.Email, string(hash), req.Role).Scan(&newUserID)
        
    if err != nil {
        fmt.Println("❌ Error creating user:", err)
        http.Error(w, "Failed to create user", http.StatusInternalServerError)
        return
    }
    
    w.WriteHeader(http.StatusCreated)
}

func getAttachmentsHandler(w http.ResponseWriter, r *http.Request) {
    issueKey := r.PathValue("id")
    
    rows, err := dbpool.Query(context.Background(), "SELECT id, issue_key, filename, file_url, created_at FROM issue_attachments WHERE issue_key = $1 ORDER BY created_at DESC", issueKey)
    if err != nil {
        http.Error(w, "Failed to fetch attachments", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var attachments []Attachment
    for rows.Next() {
        var a Attachment
        if err := rows.Scan(&a.ID, &a.IssueKey, &a.Filename, &a.FileURL, &a.CreatedAt); err != nil {
            continue
        }
        attachments = append(attachments, a)
    }
    
    if attachments == nil { attachments = []Attachment{} }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(attachments)
}

func uploadAttachmentHandler(w http.ResponseWriter, r *http.Request) {
    issueKey := r.PathValue("id")

    // Parse the incoming multipart form (max 10 MB)
    r.ParseMultipartForm(10 << 20)

    // Retrieve the file from form data
    file, handler, err := r.FormFile("file")
    if err != nil {
        http.Error(w, "Error retrieving file", http.StatusBadRequest)
        return
    }
    defer file.Close()

    // Create a unique filename and path
    safeFilename := fmt.Sprintf("%d_%s", time.Now().UnixNano(), handler.Filename)
    filePath := filepath.Join("uploads", safeFilename)
    fileURL := "http://localhost:8080/uploads/" + safeFilename

    // Save the file physically to the disk
    dst, err := os.Create(filePath)
    if err != nil {
        http.Error(w, "Error saving file", http.StatusInternalServerError)
        return
    }
    defer dst.Close()
    io.Copy(dst, file)

    // Save the metadata to PostgreSQL
    _, err = dbpool.Exec(context.Background(), 
        "INSERT INTO issue_attachments (issue_key, filename, file_url) VALUES ($1, $2, $3)", 
        issueKey, handler.Filename, fileURL)

    if err != nil {
        http.Error(w, "Database error", http.StatusInternalServerError)
        return
    }
    w.WriteHeader(http.StatusCreated)
}

func toggleUserStatusHandler(w http.ResponseWriter, r *http.Request) {
    id := r.PathValue("id")
    _, err := dbpool.Exec(context.Background(), "UPDATE users SET is_active = NOT is_active WHERE id = $1", id)
    if err != nil {
        http.Error(w, "Failed to update user", http.StatusInternalServerError)
        return
    }
    w.WriteHeader(http.StatusOK)
}

func resetPasswordHandler(w http.ResponseWriter, r *http.Request) {
    id := r.PathValue("id")
    var req struct { Password string `json:"password"` }
    json.NewDecoder(r.Body).Decode(&req)

    hash, _ := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
    _, err := dbpool.Exec(context.Background(), "UPDATE users SET password_hash = $1 WHERE id = $2", string(hash), id)
    
    if err != nil {
        http.Error(w, "Failed to reset password", http.StatusInternalServerError)
        return
    }
    w.WriteHeader(http.StatusOK)
}

func archiveProjectHandler(w http.ResponseWriter, r *http.Request) {
    id := r.PathValue("id")
    _, err := dbpool.Exec(context.Background(), "UPDATE projects SET is_archived = TRUE WHERE id = $1", id)
    if err != nil {
        http.Error(w, "Failed to archive project", http.StatusInternalServerError)
        return
    }
    w.WriteHeader(http.StatusOK)
}

func getAdminUsersHandler(w http.ResponseWriter, r *http.Request) {
    rows, err := dbpool.Query(context.Background(), "SELECT id, email, role, is_active FROM users ORDER BY id ASC")
    if err != nil {
        http.Error(w, "Failed to fetch users", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var users []User
    for rows.Next() {
        var u User
        if err := rows.Scan(&u.ID, &u.Email, &u.Role, &u.IsActive); err == nil {
            users = append(users, u)
        }
    }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(users)
}

func getAdminProjectsHandler(w http.ResponseWriter, r *http.Request) {
    rows, err := dbpool.Query(context.Background(), "SELECT id, name, project_key, description, is_archived FROM projects ORDER BY id ASC")
    if err != nil {
        http.Error(w, "Failed to fetch projects", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var projects []Project
    for rows.Next() {
        var p Project
        if err := rows.Scan(&p.ID, &p.Name, &p.ProjectKey, &p.Description, &p.IsArchived); err == nil {
            projects = append(projects, p)
        }
    }
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(projects)
}

func main() {
	// 1. Connect to PostgreSQL (running in Docker)
	databaseUrl := "postgres://postgres:supersecret@localhost:5432/bugsbunny"
	
	var err error
	dbpool, err = pgxpool.New(context.Background(), databaseUrl)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Unable to create connection pool: %v\n", err)
		os.Exit(1)
	}
	defer dbpool.Close()
	fmt.Println("✅ Connected to Bugsbunny Database!")

	// Initialize the Plugin System
	pluginManager, err = NewPluginManager(context.Background(), "./plugins")
	if err != nil {
		log.Fatalf("Failed to initialize plugin manager: %v", err)
	}
	
	// Generate a secure hash for "admin123" and update our dummy admin
	hash, _ := bcrypt.GenerateFromPassword([]byte("admin123"), bcrypt.DefaultCost)
	dbpool.Exec(context.Background(), "UPDATE users SET password_hash = $1 WHERE email = 'admin@bugsbunny.local'", string(hash))

	// 2. Setup the Go 1.22+ Router (Just one mux!)
	mux := http.NewServeMux()
	
	// Ensure the uploads and plugins directory exists on disk
	os.MkdirAll("./uploads", os.ModePerm)
	os.MkdirAll("./plugins", os.ModePerm)

	// Serve the uploaded files as static assets (unprotected so `<img>` tags work)
	mux.Handle("GET /uploads/", http.StripPrefix("/uploads/", http.FileServer(http.Dir("./uploads"))))

	// Unprotected Route
	mux.HandleFunc("POST /login", loginHandler)

	// Protected Routes (Wrapped in the Bouncer!)
	mux.HandleFunc("GET /issues", authMiddleware(getAllIssuesHandler))
	mux.HandleFunc("GET /issues/{id}", authMiddleware(getIssueHandler))
	mux.HandleFunc("POST /issues", authMiddleware(createIssueHandler))
	mux.HandleFunc("PUT /issues/{id}", authMiddleware(updateIssueHandler))
	mux.HandleFunc("DELETE /issues/{id}", authMiddleware(deleteIssueHandler))
	mux.HandleFunc("GET /projects", authMiddleware(getProjectsHandler))
	mux.HandleFunc("POST /projects", authMiddleware(createProjectHandler))
	mux.HandleFunc("POST /users", authMiddleware(createUserHandler))
	mux.HandleFunc("GET /issues/{id}/comments", authMiddleware(getCommentsHandler))
	mux.HandleFunc("POST /issues/{id}/comments", authMiddleware(addCommentHandler))
	mux.HandleFunc("GET /issues/{id}/attachments", authMiddleware(getAttachmentsHandler))
	mux.HandleFunc("POST /issues/{id}/attachments", authMiddleware(uploadAttachmentHandler))
	mux.HandleFunc("PUT /admin/users/{id}/toggle", adminMiddleware(toggleUserStatusHandler))
	mux.HandleFunc("PUT /admin/users/{id}/password", adminMiddleware(resetPasswordHandler))
	mux.HandleFunc("PUT /admin/projects/{id}/archive", adminMiddleware(archiveProjectHandler))
	mux.HandleFunc("GET /admin/users", adminMiddleware(getAdminUsersHandler))
	mux.HandleFunc("GET /admin/projects", adminMiddleware(getAdminProjectsHandler))
	mux.HandleFunc("GET /profile", authMiddleware(userProfileHandler))

	// 3. The Global CORS Wrapper
	corsMiddleware := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Access-Control-Allow-Origin", "*")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

			if r.Method == "OPTIONS" {
				w.WriteHeader(http.StatusOK)
				return
			}
			next.ServeHTTP(w, r)
		})
	}

	// 4. Start the Server
	fmt.Println("🚀 Bugsbunny Engine starting on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", corsMiddleware(mux)))
}

func getIssueHandler(w http.ResponseWriter, r *http.Request) {
    id := r.PathValue("id") // Extract the bug ID from the URL

    var issue Issue
    err := dbpool.QueryRow(context.Background(), 
        "SELECT issue_key, project_id, title, body, status, reporter_id, custom_data FROM issues WHERE issue_key = $1", 
        id).Scan(&issue.IssueKey, &issue.ProjectID, &issue.Title, &issue.Body, &issue.Status, &issue.ReporterID, &issue.CustomData)
    
    if err != nil {
        http.Error(w, "Issue not found", http.StatusNotFound)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(issue)
}

