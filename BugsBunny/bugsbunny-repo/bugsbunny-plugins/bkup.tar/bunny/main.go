package main

import (
    "unsafe"
)

// main is required for TinyGo to compile to WASM, even if empty
func main() {}

//export malloc
func malloc(size uint32) *byte {
    buf := make([]byte, size)
    return &buf[0]
}

//export can_transition
func can_transition(currPtr, currSize, newPtr, newSize uint32) uint32 {
    // 1. Decode the pointers back into strings
    currentStatus := ptrToString(currPtr, currSize)
    newStatus := ptrToString(newPtr, newSize)

    // --- CUSTOM BUSINESS LOGIC ---
    
    // Rule 1: A closed ticket can never be reopened
    if currentStatus == "closed" {
        return 0 // 0 = False (Rejected)
    }

    // Rule 2: Tickets must go through "in_progress" before being "resolved"
    if currentStatus == "open" && newStatus == "resolved" {
        return 0 
    }

    // All other transitions are allowed
    return 1 // 1 = True (Approved)
}

// Helper to read memory safely
func ptrToString(ptr uint32, size uint32) string {
    b := unsafe.Slice((*byte)(unsafe.Pointer(uintptr(ptr))), size)
    return string(b)
}
